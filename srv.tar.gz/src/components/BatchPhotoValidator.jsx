import React, { useState, useEffect, useCallback } from 'react';
import { Checkbox, Loader, Check, X, AlertTriangle, Users, Eye, Upload, Save, RefreshCw } from 'lucide-react';

const BatchPhotoValidator = () => {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPhotos, setSelectedPhotos] = useState({});
  const [stats, setStats] = useState({
    total: 0,
    validated: 0,
    rejected: 0,
    remaining: 0,
    reject_reasons: {}
  });
  const [rejectReason, setRejectReason] = useState('');
  const [customRejectReason, setCustomRejectReason] = useState('');
  const [processingBatch, setProcessingBatch] = useState(false);
  const [batchResults, setBatchResults] = useState(null);
  const [activeUsers, setActiveUsers] = useState([]);
  const [lockedPhotos, setLockedPhotos] = useState({});
  const [viewMode, setViewMode] = useState('grid'); // 'grid' ou 'list'
  const [sortField, setSortField] = useState('name');
  const [sortDirection, setSortDirection] = useState('asc');
  const [filterResolution, setFilterResolution] = useState('');
  const [filterType, setFilterType] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Récupérer la liste des photos
  const fetchPhotos = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/photos/list', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la récupération des photos');
      }
      const data = await response.json();
      setPhotos(data);
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Récupérer les statistiques
  const fetchStats = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:5000/api/photos/stats', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la récupération des statistiques');
      }
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Erreur:', error);
    }
  }, []);

  // Récupérer les utilisateurs actifs et photos verrouillées
  const fetchCollaborationStatus = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:5000/api/collaboration/status', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la récupération du statut de collaboration');
      }
      const data = await response.json();
      setActiveUsers(data.active_users || []);
      
      // Convertir la liste des photos verrouillées en objet pour un accès plus facile
      const locks = {};
      (data.locked_photos || []).forEach(lock => {
        locks[lock.photo_id] = {
          username: lock.username,
          expires_at: lock.expires_at
        };
      });
      setLockedPhotos(locks);
    } catch (error) {
      console.error('Erreur:', error);
    }
  }, []);

  // Charger les données initiales
  useEffect(() => {
    fetchPhotos();
    fetchStats();
    fetchCollaborationStatus();
    
    // Configurer l'actualisation périodique des données de collaboration
    const interval = setInterval(fetchCollaborationStatus, 30000);
    return () => clearInterval(interval);
  }, [fetchPhotos, fetchStats, fetchCollaborationStatus]);

  // Gérer la sélection/désélection d'une photo
  const togglePhotoSelection = (photoId) => {
    if (lockedPhotos[photoId] && lockedPhotos[photoId].username !== localStorage.getItem('username')) {
      // Photo verrouillée par un autre utilisateur, ne pas permettre la sélection
      return;
    }
    
    setSelectedPhotos(prev => {
      const newSelection = { ...prev };
      if (newSelection[photoId]) {
        delete newSelection[photoId];
      } else {
        newSelection[photoId] = true;
      }
      return newSelection;
    });
  };

  // Sélectionner ou désélectionner toutes les photos
  const toggleSelectAll = () => {
    if (Object.keys(selectedPhotos).length === photos.length) {
      // Tout désélectionner
      setSelectedPhotos({});
    } else {
      // Sélectionner toutes les photos non verrouillées par d'autres utilisateurs
      const newSelection = {};
      photos.forEach(photo => {
        if (!lockedPhotos[photo.id] || lockedPhotos[photo.id].username === localStorage.getItem('username')) {
          newSelection[photo.id] = true;
        }
      });
      setSelectedPhotos(newSelection);
    }
  };

  // Traiter le lot de photos sélectionnées
  const processBatch = async (decision) => {
    if (Object.keys(selectedPhotos).length === 0) {
      alert('Veuillez sélectionner au moins une photo');
      return;
    }

    if (decision === 'refuse' && !rejectReason) {
      alert('Veuillez sélectionner une raison de rejet');
      return;
    }

    // Confirmer l'action
    if (!window.confirm(`Êtes-vous sûr de vouloir ${decision === 'valider' ? 'valider' : 'refuser'} ${Object.keys(selectedPhotos).length} photos ?`)) {
      return;
    }

    setProcessingBatch(true);
    setBatchResults(null);

    try {
      const finalRejectReason = rejectReason === 'custom' ? customRejectReason : rejectReason;
      
      const response = await fetch('http://localhost:5000/api/photos/batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          photoIds: Object.keys(selectedPhotos),
          decision: decision,
          rejectReason: decision === 'refuse' ? finalRejectReason : null
        }),
      });

      if (!response.ok) {
        throw new Error('Erreur lors du traitement par lot');
      }

      const data = await response.json();
      setBatchResults(data.results);
      
      // Réinitialiser la sélection
      setSelectedPhotos({});
      setRejectReason('');
      setCustomRejectReason('');
      
      // Actualiser les données
      fetchPhotos();
      fetchStats();
      
    } catch (error) {
      console.error('Erreur:', error);
      alert(`Erreur: ${error.message}`);
    } finally {
      setProcessingBatch(false);
    }
  };

  // Filtrer et trier les photos
  const filteredAndSortedPhotos = useCallback(() => {
    if (!photos || photos.length === 0) return [];
    
    // Filtrer les photos
    let filtered = [...photos];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(photo => 
        photo.originalName.toLowerCase().includes(query)
      );
    }
    
    if (filterResolution) {
      filtered = filtered.filter(photo => {
        if (!photo.width || !photo.height) return false;
        
        const resolution = photo.width * photo.height;
        switch (filterResolution) {
          case 'high': return resolution >= 4000000; // Plus de 4MP
          case 'medium': return resolution >= 1000000 && resolution < 4000000; // 1-4MP
          case 'low': return resolution < 1000000; // Moins de 1MP
          default: return true;
        }
      });
    }
    
    if (filterType) {
      filtered = filtered.filter(photo => {
        if (!photo.type) return false;
        return photo.type.toLowerCase().includes(filterType.toLowerCase());
      });
    }
    
    // Trier les photos
    filtered.sort((a, b) => {
      let valueA, valueB;
      
      switch (sortField) {
        case 'name':
          valueA = a.originalName.toLowerCase();
          valueB = b.originalName.toLowerCase();
          break;
        case 'size':
          valueA = parseFloat(a.size);
          valueB = parseFloat(b.size);
          break;
        case 'date':
          valueA = new Date(a.modified);
          valueB = new Date(b.modified);
          break;
        case 'resolution':
          valueA = (a.width || 0) * (a.height || 0);
          valueB = (b.width || 0) * (b.height || 0);
          break;
        default:
          valueA = a.originalName.toLowerCase();
          valueB = b.originalName.toLowerCase();
      }
      
      // Inverser l'ordre si le sens est descendant
      return sortDirection === 'asc' 
        ? (valueA > valueB ? 1 : -1)
        : (valueA < valueB ? 1 : -1);
    });
    
    return filtered;
  }, [photos, searchQuery, filterResolution, filterType, sortField, sortDirection]);

  // Rendu en mode grille
  const renderGridView = () => {
    const filtered = filteredAndSortedPhotos();
    
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {filtered.map(photo => {
          const isSelected = selectedPhotos[photo.id] || false;
          const isLocked = lockedPhotos[photo.id] && lockedPhotos[photo.id].username !== localStorage.getItem('username');
          
          return (
            <div 
              key={photo.id}
              className={`relative rounded-lg overflow-hidden border ${isSelected ? 'border-blue-500' : 'border-gray-200'} ${isLocked ? 'opacity-50' : ''}`}
              onClick={() => !isLocked && togglePhotoSelection(photo.id)}
            >
              <div className="aspect-w-1 aspect-h-1">
                <img
                  src={`http://localhost:5000/api/photos/${photo.id}?size=thumbnail`}
                  alt={photo.originalName}
                  className="object-cover w-full h-full"
                  loading="lazy"
                />
              </div>
              
              {isSelected && (
                <div className="absolute top-2 right-2 bg-blue-500 text-white p-1 rounded-full">
                  <Check className="w-4 h-4" />
                </div>
              )}
              
              {isLocked && (
                <div className="absolute top-2 left-2 bg-yellow-500 text-white p-1 rounded-full" title={`Verrouillé par ${lockedPhotos[photo.id].username}`}>
                  <Users className="w-4 h-4" />
                </div>
              )}
              
              <div className="p-2 text-xs truncate">{photo.originalName}</div>
              <div className="p-2 pt-0 text-xs text-gray-600">
                {photo.width && photo.height ? `${photo.width}×${photo.height}` : ''}
                {photo.paperFormat ? ` (${photo.paperFormat})` : ''}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Rendu en mode liste
  const renderListView = () => {
    const filtered = filteredAndSortedPhotos();
    
    return (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-4 py-2">
                <input 
                  type="checkbox" 
                  checked={Object.keys(selectedPhotos).length > 0 && Object.keys(selectedPhotos).length === photos.length}
                  onChange={toggleSelectAll}
                  className="h-4 w-4"
                />
              </th>
              <th 
                className="px-4 py-2 text-left cursor-pointer"
                onClick={() => {
                  if (sortField === 'name') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortField('name');
                    setSortDirection('asc');
                  }
                }}
              >
                Nom {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th 
                className="px-4 py-2 text-left cursor-pointer"
                onClick={() => {
                  if (sortField === 'size') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortField('size');
                    setSortDirection('asc');
                  }
                }}
              >
                Taille {sortField === 'size' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th 
                className="px-4 py-2 text-left cursor-pointer"
                onClick={() => {
                  if (sortField === 'resolution') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortField('resolution');
                    setSortDirection('asc');
                  }
                }}
              >
                Résolution {sortField === 'resolution' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th 
                className="px-4 py-2 text-left cursor-pointer"
                onClick={() => {
                  if (sortField === 'date') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortField('date');
                    setSortDirection('asc');
                  }
                }}
              >
                Date {sortField === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th className="px-4 py-2 text-left">Type</th>
              <th className="px-4 py-2 text-left">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filtered.map(photo => {
              const isSelected = selectedPhotos[photo.id] || false;
              const isLocked = lockedPhotos[photo.id] && lockedPhotos[photo.id].username !== localStorage.getItem('username');
              
              return (
                <tr 
                  key={photo.id}
                  className={`${isSelected ? 'bg-blue-50' : ''} ${isLocked ? 'opacity-50' : ''}`}
                >
                  <td className="px-4 py-2">
                    <input 
                      type="checkbox" 
                      checked={isSelected}
                      onChange={() => !isLocked && togglePhotoSelection(photo.id)}
                      disabled={isLocked}
                      className="h-4 w-4"
                    />
                  </td>
                  <td className="px-4 py-2 truncate max-w-xs" title={photo.originalName}>
                    {photo.originalName}
                    {isLocked && (
                      <span className="ml-2 text-yellow-600" title={`Verrouillé par ${lockedPhotos[photo.id].username}`}>
                        <Users className="w-4 h-4 inline" />
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-2">{photo.size}</td>
                  <td className="px-4 py-2">
                    {photo.width && photo.height ? `${photo.width}×${photo.height}` : '-'}
                    <br />
                    <span className="text-xs text-gray-500">{photo.paperFormat || ''}</span>
                  </td>
                  <td className="px-4 py-2">{photo.modified}</td>
                  <td className="px-4 py-2">{photo.type}</td>
                  <td className="px-4 py-2">
                    <a 
                      href={`http://localhost:5000/api/photos/${photo.id}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Eye className="w-4 h-4 inline mr-1" />
                      Voir
                    </a>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  // Rendu du résultat du traitement par lot
  const renderBatchResults = () => {
    if (!batchResults) return null;
    
    return (
      <div className="mt-4 p-4 bg-gray-100 rounded-lg">
        <h3 className="font-bold mb-2">Résultats du traitement par lot</h3>
        
        <div className="flex justify-between mb-2">
          <div>
            <span className="font-medium">Réussis:</span> {batchResults.success?.length || 0}
          </div>
          <div>
            <span className="font-medium">Échoués:</span> {batchResults.failed?.length || 0}
          </div>
        </div>
        
        {batchResults.failed && batchResults.failed.length > 0 && (
          <div className="mt-2">
            <h4 className="font-medium text-red-600">Erreurs:</h4>
            <ul className="text-sm">
              {batchResults.failed.map((item, idx) => (
                <li key={idx} className="mt-1">
                  {item.id}: {item.error}
                </li>
              ))}
            </ul>
          </div>
        )}
        
        <button 
          className="mt-2 px-3 py-1 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
          onClick={() => setBatchResults(null)}
        >
          Fermer
        </button>
      </div>
    );
  };
  
  // Panneau d'information sur les utilisateurs actifs
  const renderActiveUsers = () => {
    if (!activeUsers || activeUsers.length === 0) return null;
    
    return (
      <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-medium flex items-center">
          <Users className="w-4 h-4 mr-1" />
          Utilisateurs actifs ({activeUsers.length})
        </h3>
        <div className="mt-1 flex flex-wrap gap-2">
          {activeUsers.map(user => (
            <span key={user} className="px-2 py-1 bg-white text-sm rounded-full shadow-sm">
              {user}
            </span>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white shadow-xl rounded-lg overflow-hidden w-full max-w-7xl">
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Validation par lot des photos</h2>
          
          <div className="flex space-x-4">
            <div className="text-center">
              <p className="text-xs text-gray-500">Restantes</p>
              <p className="font-bold">{stats.remaining}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500">Validées</p>
              <p className="font-bold text-green-600">{stats.validated}</p>
            </div>
            <div className="text-center relative group">
              <p className="text-xs text-gray-500">Refusées</p>
              <p className="font-bold text-red-600">{stats.rejected}</p>
              
              {/* Détails des rejets (affichage au survol) */}
              <div className="absolute right-0 w-48 bg-white shadow-lg rounded-md p-2 hidden group-hover:block z-10">
                <p className="text-xs font-medium mb-1">Détails des rejets :</p>
                <div className="text-xs">
                  <div className="flex justify-between">
                    <span>Trop petite :</span> 
                    <span>{stats.reject_reasons?.trop_petite || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mal prise :</span> 
                    <span>{stats.reject_reasons?.mal_prise || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sans ID :</span> 
                    <span>{stats.reject_reasons?.sans_id || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Autre :</span> 
                    <span>{stats.reject_reasons?.autre || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Information sur les utilisateurs actifs */}
        {renderActiveUsers()}
        
        {/* Barre d'outils */}
        <div className="flex flex-wrap gap-2 mb-4">
          {/* Filtres et recherche */}
          <div className="flex-1 md:flex-none">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher..."
              className="px-3 py-2 border rounded w-full"
            />
          </div>
          
          <div className="flex-1 md:flex-none">
            <select
              value={filterResolution}
              onChange={(e) => setFilterResolution(e.target.value)}
              className="px-3 py-2 border rounded w-full"
            >
              <option value="">Toutes résolutions</option>
              <option value="high">Haute (4MP+)</option>
              <option value="medium">Moyenne (1-4MP)</option>
              <option value="low">Basse (&lt;1MP)</option>
            </select>
          </div>
          
          <div className="flex-1 md:flex-none">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border rounded w-full"
            >
              <option value="">Tous types</option>
              <option value=".jpg">.jpg / .jpeg</option>
              <option value=".png">.png</option>
              <option value=".tif">.tif / .tiff</option>
            </select>
          </div>
          
          {/* Boutons de vue */}
          <div className="flex">
            <button
              className={`px-3 py-2 border-t border-b border-l rounded-l ${viewMode === 'grid' ? 'bg-blue-100 border-blue-300' : 'bg-gray-100 border-gray-300'}`}
              onClick={() => setViewMode('grid')}
              title="Vue grille"
            >
              <i className="fas fa-th"></i>
              Grille
            </button>
            <button
              className={`px-3 py-2 border rounded-r ${viewMode === 'list' ? 'bg-blue-100 border-blue-300' : 'bg-gray-100 border-gray-300'}`}
              onClick={() => setViewMode('list')}
              title="Vue liste"
            >
              <i className="fas fa-list"></i>
              Liste
            </button>
          </div>
          
          <button
            className="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 ml-auto"
            onClick={fetchPhotos}
            title="Actualiser"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
        
        {/* Zone de sélection multiple */}
        <div className="mb-4 flex items-center gap-2">
          <button
            className="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
            onClick={toggleSelectAll}
          >
            {Object.keys(selectedPhotos).length === photos.length ? 'Désélectionner tout' : 'Sélectionner tout'}
          </button>
          
          <span className="text-sm">
            {Object.keys(selectedPhotos).length} photo(s) sélectionnée(s)
          </span>
        </div>
        
        {/* Résultats du traitement par lot */}
        {renderBatchResults()}
        
        {/* Liste des photos */}
        {loading ? (
          <div className="flex justify-center items-center py-10">
            <Loader className="w-8 h-8 animate-spin text-blue-500" />
            <span className="ml-2 text-lg">Chargement des photos...</span>
          </div>
        ) : photos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10">
            <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4" />
            <p className="text-lg">Aucune photo à valider</p>
          </div>
        ) : (
          <>
            {viewMode === 'grid' ? renderGridView() : renderListView()}
            
            {/* Pagination - À implémenter si nécessaire */}
          </>
        )}
        
        {/* Options de rejet */}
        {Object.keys(selectedPhotos).length > 0 && (
          <div className="mt-6 p-4 bg-gray-100 rounded-lg">
            <div className="mb-4">
              <p className="text-sm font-medium mb-2">Raison du rejet (si applicable):</p>
              <div className="flex flex-wrap gap-2">
                <button
                  className={`px-3 py-1 rounded text-sm ${rejectReason === 'trop-petite' ? 'bg-red-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => setRejectReason('trop-petite')}
                >
                  Trop petite
                </button>
                <button
                  className={`px-3 py-1 rounded text-sm ${rejectReason === 'mal-prise' ? 'bg-red-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => setRejectReason('mal-prise')}
                >
                  Mal prise
                </button>
                <button
                  className={`px-3 py-1 rounded text-sm ${rejectReason === 'sans-id' ? 'bg-red-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => setRejectReason('sans-id')}
                >
                  Non nommé/sans ID
                </button>
                <button
                  className={`px-3 py-1 rounded text-sm ${rejectReason === 'custom' ? 'bg-red-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => setRejectReason('custom')}
                >
                  Autre
                </button>
              </div>
              {rejectReason === 'custom' && (
                <input
                  type="text"
                  value={customRejectReason}
                  onChange={(e) => setCustomRejectReason(e.target.value)}
                  placeholder="Précisez la raison du rejet"
                  className="mt-2 border rounded px-3 py-1 w-full text-sm"
                />
              )}
            </div>
            
            {/* Actions */}
            <div className="flex justify-between">
              <button
                onClick={() => processBatch('refuse')}
                disabled={processingBatch}
                className="flex items-center px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
              >
                {processingBatch ? (
                  <Loader className="w-5 h-5 mr-2 animate-spin" />
                ) : (
                  <X className="w-5 h-5 mr-2" />
                )}
                Refuser la sélection
              </button>
              
              <button
                onClick={() => processBatch('valider')}
                disabled={processingBatch}
                className="flex items-center px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
              >
                {processingBatch ? (
                  <Loader className="w-5 h-5 mr-2 animate-spin" />
                ) : (
                  <Check className="w-5 h-5 mr-2" />
                )}
                Valider la sélection
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BatchPhotoValidator;
